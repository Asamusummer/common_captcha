from __future__ import annotations

import os

BASE_DIR = os.path.dirname(__file__)
