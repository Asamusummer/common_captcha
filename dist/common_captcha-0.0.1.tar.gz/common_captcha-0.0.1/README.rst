=========================
common_captcha
=========================

common captcha for web server

Introdution
-----------

通用验证码，包括简单验证码，数字，字母，滑块验证码等


Requirements
~~~~~~~~~~~~

- `python`_ 3.6+
- `redis`_ latest


Use Guide
---------

Installtion
~~~~~~~~~~~

Install with pip:

.. code-block:: console

    $ python -m pip install common_captcha